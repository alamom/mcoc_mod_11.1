package android.support.v4.app;

abstract interface NotificationBuilderWithActions
{
  public abstract void addAction(NotificationCompatBase.Action paramAction);
}


/* Location:              C:\tools\androidhack\marvel_bitva_chempionov_v11.1.0_mod_lenov.ru\classes.jar!\android\support\v4\app\NotificationBuilderWithActions.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */