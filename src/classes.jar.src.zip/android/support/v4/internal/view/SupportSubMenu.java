package android.support.v4.internal.view;

import android.view.SubMenu;

public abstract interface SupportSubMenu
  extends SupportMenu, SubMenu
{}


/* Location:              C:\tools\androidhack\marvel_bitva_chempionov_v11.1.0_mod_lenov.ru\classes.jar!\android\support\v4\internal\view\SupportSubMenu.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */