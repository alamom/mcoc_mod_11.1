package android.support.v4.animation;

import android.view.View;

abstract interface AnimatorProvider
{
  public abstract void clearInterpolator(View paramView);
  
  public abstract ValueAnimatorCompat emptyValueAnimator();
}


/* Location:              C:\tools\androidhack\marvel_bitva_chempionov_v11.1.0_mod_lenov.ru\classes.jar!\android\support\v4\animation\AnimatorProvider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */