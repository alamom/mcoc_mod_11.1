package android.support.v4.view;

import android.view.View;

public abstract interface OnApplyWindowInsetsListener
{
  public abstract WindowInsetsCompat onApplyWindowInsets(View paramView, WindowInsetsCompat paramWindowInsetsCompat);
}


/* Location:              C:\tools\androidhack\marvel_bitva_chempionov_v11.1.0_mod_lenov.ru\classes.jar!\android\support\v4\view\OnApplyWindowInsetsListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */