package com.MAT.sdk;

public final class Manifest
{
  public static final class permission
  {
    public static final String C2D_MESSAGE = "com.kabam.marvelbattle.permission.C2D_MESSAGE";
  }
}


/* Location:              C:\tools\androidhack\marvel_bitva_chempionov_v11.1.0_mod_lenov.ru\classes.jar!\com\MAT\sdk\Manifest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */