package com.amazon.cptplugins.concurrent;

public abstract interface CallbackHandler
{
  public abstract void handleSdkCallback(String paramString);
}


/* Location:              C:\tools\androidhack\marvel_bitva_chempionov_v11.1.0_mod_lenov.ru\classes.jar!\com\amazon\cptplugins\concurrent\CallbackHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */