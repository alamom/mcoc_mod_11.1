package com.adjust.sdk;

public abstract interface OnAttributionChangedListener
{
  public abstract void onAttributionChanged(AdjustAttribution paramAdjustAttribution);
}


/* Location:              C:\tools\androidhack\marvel_bitva_chempionov_v11.1.0_mod_lenov.ru\classes.jar!\com\adjust\sdk\OnAttributionChangedListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */